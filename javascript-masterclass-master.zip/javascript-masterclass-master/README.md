<h1 align="center">
<img width="40" valign="bottom" src="https://ultimatecourses.com/static/icons/javascript.svg">
JavaScript Masterclass: Starter Project
</h1>
<h4 align="center">Starter Project for the Ultimate Courses <a href="https://ultimatecourses.com/learn/javascript-masterclass" target="_blank">JavaScript Masterclass course</a>.</h4>

---

<div align="center">
<a href="https://ultimatecourses.com/courses/javascript" target="_blank"><img width="100%" src="https://ultimatecourses.com/static/banners/ultimate-javascript-leader.svg"></a>
</div>

---

Members, please refer to the [course setup](https://app.ultimatecourses.com/course/javascript-masterclass) instructions to get started!
